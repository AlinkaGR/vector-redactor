﻿using System.Windows.Media;

interface IBackgroundChanger
{
    Brush Background
    {
        set;
        get;
    }
}
